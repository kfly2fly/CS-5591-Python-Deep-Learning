class Employee:
  empCount = 0  # class attributes
  employeeList = []  # keeps track of class instances

  # default constructor
  def __init__(self, iden, n, dept, sal, full=True, bal=0):
    self.id = iden
    self.name = n
    self.department = dept
    self.salary = float(sal)
    self.balance = float(bal)
    self.isEmployed = True
    self.fullTime = full
    Employee.empCount += 1
    # keep list of class objects for the class methods
    Employee.employeeList.append(self)

  # returns True if employee is employed
  def isEmployed(self):
    return self.isEmployed

  # modifies employee salary by given raise %
  def giveRaise(self, raiseAmt):
    self.salary *= raiseAmt

  # Given an employee_id, this method fires that employee
  @classmethod
  def Fire(cls, id_num):
    for emp in cls.employeeList:
      if id_num == emp.id:
        emp.isEmployed = False
        emp.salary = 0

  # Given an employee_id, this method returns True if the employee is full time, else false
  @classmethod
  def isFullTime(cls, id_num):
    for emp in cls.employeeList:
      if id_num == emp.id:
        return emp.fullTime

  # This method pays all active employees
  @classmethod
  def pay(cls):
    for emp in cls.employeeList:
      emp.balance += emp.salary

  # this method computes the average salary for full and part time employees
  @classmethod
  def AvgSal(cls):
    totalFull, totalPart, countFull, countPart = 0, 0, 0, 0
    for emp in cls.employeeList:
      if emp.fullTime:
        totalFull += emp.salary
        countFull += 1
      else:
        totalPart += emp.salary
        countPart += 1
    return totalFull / countFull, totalPart / countPart

  # This method prints our metrics
  @classmethod
  def out(cls):
    output = ""
    for emp in cls.employeeList:
      output += emp.name + ', ' + emp.id + ', ' + emp.department + '\n'
      output += 'Current Salary: ${:.2f}\n'.format(emp.salary)
      if emp.isEmployed == False:
        output += 'Not employed with the company.\n'
      output += 'Pay earned to date: ${:.2f}\n'.format(emp.balance)
      if emp.fullTime:
        output += 'Full-Time\n'
      else:
        output += 'Part-Time\n'
      output += '\n'
    output += '\n'
    output += 'Total number of employees: ' + str(Employee.empCount) + '\n'
    avgFull, avgPart = Employee.AvgSal()
    output += 'Average Salary paid to all Full-time employees: ${:.2f}\n'.format(
        avgFull)
    output += 'Average Salary paid to all Part-time employees: ${:.2f}\n'.format(
        avgPart)
    print(output)

#This class inherits from the Employee class
class Full_time(Employee):
  employeeListFull = []

  #default constructor which calls the parent constructor
  def __init__(self, iden, n, dept, sal, bal=0):
    Employee.__init__(self, iden, n, dept, sal, bal)
    Full_time.employeeListFull.append(self)

  #This method passes a default raise amount for full time employees, and passes that value to parent method
  @classmethod
  def giveRaise(cls, id_num, raiseAmt=1.1):
    for emp in cls.employeeListFull:
      if id_num == emp.id:
        Employee.giveRaise(emp, raiseAmt)

#This class inherits from the Employee class
class Part_time(Employee):
  employeeListPart = []

  def __init__(self, iden, n, dept, sal, bal=0):
    Employee.__init__(self, iden, n, dept, sal, bal)
    Part_time.employeeListPart.append(self)

  @classmethod
  def giveRaise(cls, id_num, raiseAmt=1.05):
    for emp in cls.employeeListPart:
      if id_num == emp.id:
        Employee.giveRaise(emp, raiseAmt)

def parse(line):
  if line[0] == 'NEW':
    if line[-1] == 'F':
      Full_time(line[1], line[2] + ' ' + line[3],
                line[4], float(line[5]), True)
    elif line[-1] == 'P':
      Part_time(line[1], line[2] + ' ' + line[3],
                line[4], float(line[5]), False)

  elif line[0] == 'PAY':
    Employee.pay()

  elif line[0] == 'RAISE':
    if Employee.isFullTime(line[1]):
      if len(line) == 2:
        Full_time.giveRaise(line[1])
      elif len(line) == 3:
        Full_time.giveRaise(line[1], 1 + float(line[2]) / 100.0)
    else:
      if len(line) == 2:
        Part_time.giveRaise(line[1])
      elif len(line) == 3:
        Part_time.giveRaise(line[1], 1 + float(line[2]) / 100.0)

  elif line[0] == 'FIRE':
    Employee.Fire(line[1])


with open('input.txt', 'r') as f:
  header = f.readline()  # read in the header
  for line in f.readlines():
    line = line.replace('\n', '')
    list_of_words = line.split(' ')
    parse(list_of_words)

Employee.out()
